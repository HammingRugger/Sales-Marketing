# Hamming CRO Agent

A full Chief Revenue Officer agent for Hamming AI, built as an attachable project skill system. It
evaluates the revenue engine the way a real CRO does, across eight domains, against the live HubSpot
CRM, with an honesty layer that refuses to invent patterns from empty fields.

## How to attach

Drop the `skills/` folder into your Claude project. Each subfolder is one skill with a SKILL.md the
agent reads on demand. The agent reads `cro-core` first, then routes through `cro-orchestrator` to
the specialist it needs. No token or script required: it runs on the HubSpot connector tools already
available in the project.

## The map

```
cro-core                         identity, Hamming context, live-vs-latent data map, evidence standard
  |
  ├─ data-readiness-gate         guards every field; refuses analysis on empty data
  |
  │  INSPECTION (present state)
  ├─ pipeline-inspection         coverage, velocity, conversion, risk, durability, hygiene
  │
  │  GENERATION (forward state)
  ├─ pipeline-generation-coverage  creation rate + forward coverage vs future quotas
  │
  │  FORECAST
  ├─ forecast-accuracy-credibility forecast range + per-rep commit trust
  │
  │  TREND
  ├─ cohort-trend-analysis       direction of every metric over time
  │
  │  ATTRIBUTION  (gated)
  ├─ source-attribution          source-to-won revenue, when source is captured
  │
  │  LEARNING  (gated)
  ├─ win-loss-deal-quality       why deals win and lose, discounting, deal shape
  │
  │  ECONOMICS
  ├─ velocity-conversion-economics  stage value-leak, deal-size distribution, ACV, cycle economics
  │
  │  DURABLE REVENUE  (gated)
  ├─ retention-expansion-nrr     churn, expansion, NRR when ARR is populated
  │
  │  CAPACITY
  ├─ capacity-quota-modeling     headcount-to-target, ramp, hiring runway
  ├─ rep-performance-scorecard   per-seller read for one-on-ones
  │
  │  DELIVERY
  ├─ cro-board-narrative         board and executive communication
  └─ cro-orchestrator            routes among all of the above and synthesizes
```

## The three standard runs

- **Weekly pulse:** inspection + rep scorecard. Operational, for the Monday review.
- **Monthly deep:** inspection, generation, forecast, trend, economics, rep scorecard.
- **Quarterly board:** the monthly run plus capacity, retention, attribution and win-loss where data
  allows, assembled through the board narrative.

Ask the orchestrator for a run by name, or call any specialist directly for a single answer.

## The honesty layer

This is what separates the agent from a dashboard. Every field that might be empty passes through
`data-readiness-gate` before any skill computes on it. At the last audit of the Hamming portal:

- Traffic source collapsed to "Offline Sources" → attribution is **data-starved** until source is captured.
- Closed-lost / closed-won reasons blank → win-loss reasons **data-starved** until reps fill them.
- ARR / MRR unpopulated → true NRR **data-starved**; retention runs off `amount` as a labeled proxy.
- Stage-history timing not exposed by the connector → time-in-stage is derived, not measured.
- Bulk migration in one month → that cohort is excluded from rate math as an artifact.

Skills that depend on starved fields are built and ready; they will switch from proxy to real metric
the moment the team starts capturing the data, and each one names the exact capture behavior that
unlocks it.

## Evidence tags used throughout

**(Measured)** computed from a live populated field, with count. **(Assessed)** judged against a
benchmark or the account's own history. **(Assumption to confirm)** not yet grounded in data.
**(Data-starved)** field exists but is not populated enough to trust, with the capture fix named.

## Data upgrades that sharpen the agent, in priority order

1. Populate `hs_arr` / `hs_mrr` on deals → unlocks true NRR and SaaS unit economics.
2. Capture a controlled `closed_lost_reason` at every close → unlocks win-loss learning.
3. Set real lead source or `referral_source` at deal creation → unlocks attribution.
4. Assign every deal an owner → makes capacity and forecast math trustworthy.
5. Let stage-history accumulate post-migration → unlocks true velocity and slip credibility.
