# Installing the Hamming CRO Agent in Claude Desktop

You have two install paths. The plugin path is recommended: one install, the whole agent stays
together, and it works in chat, the Desktop Chat tab, and Cowork.

## Path A — Install as one plugin (recommended)

The file `hamming-cro-agent-plugin.zip` is a complete plugin: a `plugin.json` manifest at the root
with the fourteen skills in a `skills/` folder beside it.

1. Open Claude Desktop.
2. Click **Customize** in the left sidebar.
3. Open the **Plugins** tab.
4. In the **Personal plugins** section, click the **+** button and choose to upload a custom plugin
   file.
5. Select `hamming-cro-agent-plugin.zip`.
6. The fourteen skills install together, namespaced under the plugin. Type `/` in chat to see them.

Plugins you add yourself are saved locally on your computer. The bundled skills are then available
in chat and in Cowork automatically, triggered by description when a revenue task matches.

## Path B — Install skills individually

If you prefer skills in your global Skills list rather than a plugin bundle, use the individual ZIPs
in the `skill-zips/` folder. For each one:

1. **Customize > Skills**, click **+**, choose **Create skill**.
2. Upload the skill's ZIP (for example `cro-core.zip`).
3. Repeat for all fourteen. Install `cro-core` and `cro-orchestrator` first; the others build on them.

This works, but it is fourteen uploads and the skills are not bundled, so prefer Path A unless you
have a reason to keep them separate.

## After installing: set up the project and connector

1. Create a project in the sidebar named **Hamming CRO**.
2. Connect the **HubSpot** connector to it so the agent can pull live deal data. The agent runs on
   the same HubSpot tools used to build it; no token or script is needed.
3. Add a one-line project instruction: *"Operate as the Hamming CRO agent. Read cro-core before any
   revenue task and route through cro-orchestrator."* This guarantees the routing and the
   data-readiness discipline engage every time.

## Using it

- Broad request ("run the monthly revenue review") → the orchestrator routes and synthesizes.
- Specific request ("how is each rep doing", "are we creating enough pipeline") → the matching skill
  fires directly.
- Ask for a "weekly pulse", "monthly deep evaluation", or "quarterly board read" to run a preset
  bundle at the right depth.

## A note on what runs today versus later

Several skills depend on HubSpot fields that are not yet populated in the portal (traffic source,
loss reasons, ARR/MRR). Those skills are installed and ready but will report as data-starved with the
exact capture fix named, and switch to real metrics the moment the team starts filling those fields.
This is by design: the agent tells you what it cannot yet measure rather than inventing it.
