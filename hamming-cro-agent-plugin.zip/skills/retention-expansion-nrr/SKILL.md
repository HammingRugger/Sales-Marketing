---
name: retention-expansion-nrr
description: >
  Evaluate durable revenue after the close: churn, expansion, and net revenue retention, because a
  CRO owns revenue rather than bookings. Use whenever the user asks "what's our retention", "how much
  are we churning", "what's our NRR", "is the installed base growing or shrinking", "where's our
  expansion pipeline", or any question about revenue that persists past the first close. Bookings that
  churn in two quarters are not revenue, and this skill is how a CRO sees the difference. It inherits
  from cro-core and depends heavily on data-readiness, since recurring-revenue fields are often
  unpopulated. For new-business pipeline use pipeline-generation-coverage.
---

# Retention, Expansion, and Net Revenue Retention

The most common way a revenue picture lies is by celebrating bookings while the installed base
quietly leaks. This skill closes that gap. For a SaaS infrastructure company like Hamming, net
revenue retention is arguably the single most important long-run number, because durable expanding
revenue is what compounds and what the company is ultimately valued on.

## Readiness gate first

Run data-readiness-gate on hs_arr, hs_mrr, and the Churned stage population. At last audit ARR and
MRR were blank, so true recurring-revenue retention cannot yet be computed and must be flagged as the
single highest-value data upgrade the team can make. Until those fields are populated, this skill
runs an approximation off closed-won amount and the Churned stage, and labels it clearly as a proxy,
not true NRR.

## What it computes

**Churn read.** The Churned stage and any churn-flagged deals: count, value, and which cohorts or
deal types churn most. Even as a proxy off amount, this shows whether the installed base is leaking
and where. Surface churned value against won value to give a crude gross-retention sense.

**Expansion pipeline.** Deals that represent upsell or expansion into existing customers rather than
net-new logos, identified by deal type or association to an existing customer company. A CRO wants
expansion pipeline reported separately from new-business pipeline, because expansion converts at a
higher rate and is cheaper to win, and a thin expansion pipeline is a forward-NRR warning.

**Net revenue retention, when data allows.** With ARR populated, the standard NRR: starting recurring
revenue for a cohort plus expansion minus contraction and churn, over starting recurring revenue.
Report gross and net separately. Without ARR, state that NRR is not yet computable and give the
proxy retention read instead, with the explicit note that populating ARR/MRR unlocks the real metric.

## Hamming framing

For an enterprise voice-AI QA platform, land-and-expand is the likely growth model, so the ratio of
expansion to new-business pipeline is a strategic signal. A healthy infrastructure company grows the
installed base faster than it churns it and expands existing accounts steadily. Frame the retention
read against that model.

## Output

Lead with the durable-revenue verdict: is the installed base growing or leaking, and is expansion
pipeline sufficient. Then the churn read, the expansion-versus-new-business split, and NRR if
computable or its proxy if not, with the ARR population fix named as the upgrade path. Tag true NRR
Measured only when ARR is populated; otherwise tag the proxy Data-starved and Assessed.
