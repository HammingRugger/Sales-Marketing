---
name: cohort-trend-analysis
description: >
  Convert pipeline snapshots into time series and report the direction of every key metric: is win
  rate improving or decaying, is cycle time lengthening, are recent created cohorts healthier than
  older ones. Use whenever the user asks "is this getting better or worse", "what's the trend",
  "how does this quarter compare", "are recent deals better than older ones", or any question about
  movement over time. A snapshot cannot show decay; this skill exists to show direction, which is
  the whole game in revenue. It inherits from cro-core and depends on data-readiness-gate and the
  migration caveat. For a single-point read use pipeline-inspection.
---

# Cohort and Trend Analysis

Every other inspection skill produces a snapshot. This one produces the derivative: which way things
are moving. A pipeline that is healthy and decaying is a different decision than one that is mediocre
and improving, and only a time series can tell them apart.

## The migration discipline first

Before any trend, re-check the creation-date distribution per cro-core. A bulk-migration month will
dominate and distort every cohort comparison. Exclude it from rate math and state the real
observable window. In a young portal the honest trend window may be only a few months; report that
limit rather than drawing a long trend line through three data points.

## What it computes

**Created-cohort health.** Group deals by creation month or quarter and track, for each cohort, its
eventual win rate, average deal size, and cycle length. This answers whether the deals you are
sourcing now are better or worse than the deals you sourced before, which is the leading indicator
of revenue quality. A declining cohort win rate is an early warning that upstream targeting or
qualification is slipping.

**Metric trends over time.** Win rate, average deal size, cycle length, creation rate, and stage
conversion, each as a series across the observable window. Report direction and magnitude, and flag
any metric whose trend contradicts the headline snapshot, since those tensions are where the real
story usually sits.

**Period-over-period comparison.** This quarter versus last on the core metrics, with the caveat
about sample size made explicit when periods are thin.

## Output

Lead with the direction verdict: which metrics are improving, which are decaying, and the single
trend that most changes the forward outlook. Then the cohort table and the metric series. Where a
visual sharpens the read, render the trend as a simple chart. Tag every series Measured with its
window and sample size, and mark any trend drawn through fewer than three real periods as
provisional rather than established.
