---
name: data-readiness-gate
description: >
  Check whether a HubSpot field or dataset is populated enough to trust before any skill computes on
  it, and return a clear readiness verdict with the threshold that must be met to make the analysis
  real. Use this whenever a CRO skill is about to lean on a field whose population is uncertain,
  especially source, win-loss reason, ARR/MRR, forecast category, or stage-history timing, or
  whenever the user asks "can we even measure this yet". This skill prevents the agent from inventing
  patterns out of empty fields, which is the single most common way revenue analysis lies. It
  inherits the live-versus-latent field map from cro-core and is consulted by every other skill.
---

# Data Readiness Gate

The fastest way for a revenue agent to destroy its own credibility is to report a confident pattern
built on a field nobody fills in. This skill is the guard against that. Every skill that touches a
potentially-empty field runs it through this gate first.

## The check

For any field or field set a skill is about to use, measure three things against the relevant deal
population:
1. **Population rate.** What share of records have a non-null, non-default value. A field that is
   flat at one default value, like a traffic source that reads "Offline Sources" on nearly every
   deal, counts as unpopulated even though it is technically non-null.
2. **Distribution sanity.** Does the populated portion show real variation, or does it collapse to
   a single value that signals a default rather than captured intent.
3. **Recency.** Is the field being populated on recent deals, which tells you whether a now-started
   capture habit will make the field usable going forward even if history is blank.

## The verdict bands

- **Ready** (population above 70% with real variation): compute normally, tag results Measured.
- **Partial** (population 30 to 70%): compute on the populated subset only, report the subset size
  explicitly, and never extrapolate the subset's pattern to the whole pipeline. Tag Assessed.
- **Data-starved** (population below 30%, or collapsed to a default): do not compute a pattern. State
  that the field exists but is not yet captured, give the one specific behavior the team must adopt
  to make it real, and move on. Tag Data-starved.

## Known state at last audit

Carry these forward but re-verify, since capture habits change: traffic source data-starved
(collapsed to "Offline Sources"), closed-lost and closed-won reason data-starved (blank),
ARR/MRR data-starved (blank, use amount instead), forecast category and probability ready,
ownership and activity ready, stage-history timing unavailable through the connector.

## Output

A short readiness line per field the calling skill needs, in the form: field name, population rate,
verdict band, and if not ready, the one capture behavior that would fix it. This runs silently
inside other skills most of the time; surface it explicitly only when the user asks what is
measurable or when a headline finding would otherwise rest on a starved field.
