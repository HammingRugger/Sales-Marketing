---
name: velocity-conversion-economics
description: >
  Analyze the deeper conversion and unit economics beneath the headline rates: stage-by-stage
  conversion economics, ACV trends, deal-size distribution, cycle economics, and what each stage is
  worth. Use whenever the user asks "what's our real conversion economics", "how does deal size break
  down", "what's our ACV doing", "where do we lose the most value", or wants the economics rather than
  just the rates. This goes beneath pipeline-inspection's conversion read to the money math a CRO uses
  to decide where to invest motion. It inherits from cro-core. For the simple funnel use
  pipeline-inspection; for ACV over time use cohort-trend-analysis.
---

# Velocity, Conversion, and Unit Economics

Pipeline inspection gives the conversion rates. This skill gives the economics underneath them: what
a point of conversion is worth at each stage, how deal size is distributed rather than averaged, and
where the most value leaks. A CRO uses this to decide where a point of improvement pays off most.

## What it computes

**Stage conversion economics.** For each stage boundary, not just the advance rate but the value
that advances versus the value that dies there. A stage with a healthy rate but high dollar leakage
matters more than a low-rate stage where little money sits. Rank stages by dollars lost, not by rate,
because that is where investment in the motion pays back.

**Deal-size distribution.** The full distribution of deal sizes, not the mean, which for Hamming's
uneven land-to-platform motion is essential. Report the median, the spread, and the concentration:
what share of pipeline value sits in the largest decile of deals. A motion where a few large deals
carry most value is run differently than one of many even deals, and the distribution is what tells
you which you have.

**ACV and amount trends.** Average and median deal size over time, gated through data-readiness for
the ARR fields. Since hs_arr and hs_mrr are typically unpopulated, run this off amount and note that
true recurring ACV requires those fields to be filled, which is the upgrade path to real SaaS unit
economics.

**Cycle economics.** Cycle length by deal size band, because large deals legitimately take longer and
blending them hides the real velocity of each band. A CRO wants to know the cycle for a small land
versus a large platform deal separately.

**Velocity decomposition.** Break pipeline velocity into its four drivers (deal count, deal value,
win rate, cycle) and show which driver is helping or hurting most, so improvement effort targets the
binding constraint rather than the easiest lever.

## Output

Lead with where the most value leaks and which velocity driver is the binding constraint. Then the
stage value-leak ranking, the deal-size distribution with its concentration figure, the ACV trend,
and cycle by size band. Tag computed figures Measured with counts, gate ARR-based economics through
data-readiness, and name the single highest-payback place to improve the motion.
