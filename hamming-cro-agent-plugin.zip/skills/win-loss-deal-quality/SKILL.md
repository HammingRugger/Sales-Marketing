---
name: win-loss-deal-quality
description: >
  Analyze why deals are won and lost, where discounting erodes value, what competitive patterns
  recur, and what a good deal looks like versus a bad one. Use whenever the user asks "why are we
  losing", "what's our win-loss pattern", "are we discounting too much", "who are we losing to", or
  "what does a good deal look like". This is how a CRO learns from outcomes rather than just counting
  them. It is gated by data-readiness because reason fields are often blank, and it inherits from
  cro-core. For the headline win rate use pipeline-inspection; for win-rate trend use
  cohort-trend-analysis.
---

# Win-Loss and Deal Quality

Win rate tells you how often you win. This skill tells you why, which is the part you can act on. It
turns closed deals from a scorecard into a teacher. Like attribution, it depends on fields reps must
fill in, so the readiness gate runs first and shapes how much can honestly be said.

## Readiness gate first

Run data-readiness-gate on closed_lost_reason and closed_won_reason. At last audit both were blank
on all closed deals, which is data-starved. If that holds, do not manufacture loss themes. State
that win-loss reasons are not captured, name the fix (reps selecting a reason at close, ideally from
a short controlled list so the data aggregates), and pivot to the structural quality signals below,
which are always available from deal shape even when reasons are blank.

## Structural deal-quality signals, always available

Even with no reason fields, deal shape reveals quality:
- **Threading at close.** Won deals' contact count versus lost deals' contact count. If wins are
  consistently multi-threaded and losses single-threaded, threading is your real win driver, which
  for Hamming's enterprise motion is the expected and most actionable pattern.
- **Stage path.** Whether lost deals tend to die at a particular stage, which points to where the
  motion breaks: early deaths suggest qualification, late deaths suggest pricing, procurement, or a
  missing compliance co-buyer.
- **Size and cycle by outcome.** Whether wins and losses differ systematically in deal size or cycle
  length. A pattern where large deals lose late is a different problem than one where small deals
  never advance.

## What it computes when reasons are ready

Loss reason distribution ranked by count and by lost value, win reason distribution, and the
discount analysis: where closed-won amounts fall below list or early-stage amounts, quantifying
value erosion and which reps or deal types discount most. Competitive loss patterns when a
competitor field or reason text is captured.

## Hamming framing

For voice-AI QA deals, the highest-value win-loss questions are whether compliance involvement
correlates with wins, whether technical-champion-only deals lose, and whether deals lose to "build
in-house" or "do nothing" rather than to a named competitor. Surface these specifically when the
data allows.

## Output

If data-starved on reasons, the honest statement plus the structural quality signals from deal shape,
which carry most of the value anyway. If ready, the ranked reason distributions, the discount
erosion figure, and the competitive pattern, each tagged Measured. Always close with the one change
to the motion the patterns most support.
