---
name: pipeline-inspection
description: >
  Evaluate the present-tense health of the existing pipeline: coverage, velocity, stage conversion,
  stall and deal risk, hygiene, and durability. Use whenever the user asks "how healthy is the
  pipeline", "where are deals stalling", "which deals are at risk", "is the pipeline strong", or
  wants the current-state diagnosis. This is the inspection layer of the CRO agent and the most
  immediately actionable. It inherits methodology and the data surface from cro-core and consults
  data-readiness-gate before trusting any field. For whether enough pipeline is being created use
  pipeline-generation-coverage; for direction over time use cohort-trend-analysis.
---

# Pipeline Inspection

This is the current-state physical of the pipeline. It answers whether what exists today is healthy
enough to hit the number, and where it is breaking. It is the foundation the forward-looking skills
build on, so it runs first in most full evaluations.

## The four dimensions, read together

Health is the interaction of volume, velocity, conversion, and durability, and a weakness in one
sinks a quarter that looks fine on the others. Never report one in isolation.

**Volume and coverage.** Open qualified pipeline value over the period target. Exclude the earliest
stage from the qualified figure and report both. Then apply the context discount: the share of
pipeline that is unowned, untouched, or past its close date is not real coverage. In a migrated or
under-managed portal this discount is often the whole story, so compute it before trusting any
coverage ratio. Healthy 4-5x, floor 3x.

**Velocity.** (Open qualified deal count x average open deal value x historical win rate) / average
cycle length in days, as revenue per day. Compute win rate and cycle from the post-migration closed
cohort, not benchmarks, and say so. Trend matters more than level.

**Conversion.** Per-stage advance rates across the trailing window, with special weight on the
second-to-third stage transition where weak qualification first shows. Quantify the worst leak in
deals and dollars.

**Durability.** Concentration (what share of pipeline rides on the top one and top three deals),
slippage (value in deals already past their cycle), and staleness (value with no recent activity).
A pipeline that loses the quarter if one deal slips is fragile regardless of its size.

## Risk scoring

Score every open deal additively across timeline (time in stage versus median, overdue close, push
count, age versus cycle), engagement (activity silence, single-threading, no meetings logged),
process (out-of-order stage, missing compliance contact on a late-stage Hamming deal), and forecast
(category not committed late, missing amount). Band the result healthy, watch, at risk, critical.
For Hamming specifically, weight single-threading and a missing compliance co-buyer heavily on
late-stage enterprise deals, because those are the structural ways large voice-AI deals die.

## Hygiene read

Report ownership coverage, activity coverage, and overdue exposure as first-class findings, not
footnotes. In an under-managed portal these are the binding constraint on forecastability, and a
CRO must see them before any forecast is offered.

## Output

A scorecard leading with the verdict, the worst conversion leak, the at-risk named deals with
recovery moves, and the durability exposures. Every value Measured with its count, every verdict
Assessed against its benchmark or the account's own history. Offer the at-risk list as a workable
spreadsheet when the user intends to act on it.
