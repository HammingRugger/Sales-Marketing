---
name: capacity-quota-modeling
description: >
  Model selling capacity against the target: rep count, ramp, quota coverage, and the headcount math
  that tells a CRO whether the team can physically hit the number. Use whenever the user asks "do we
  have enough reps", "what's our quota coverage", "can this team hit the target", "how many reps do we
  need to hire", or any question connecting headcount to revenue capacity. For an early-stage team
  where the founders are still carrying pipeline, this is one of the most urgent structural questions.
  It inherits from cro-core. For pipeline sufficiency use pipeline-generation-coverage; for per-rep
  performance use rep-performance-scorecard.
---

# Capacity and Quota Modeling

This skill answers whether the team, as currently sized and ramped, can carry the target. It is the
structural counterpart to pipeline analysis: even a healthy pipeline cannot be worked if there is not
enough selling capacity to cover it, and even a thin pipeline can be fixed if there is capacity to
generate more. A CRO holds both views at once.

## What it computes

**Current capacity.** Identify the active sellers from owner data, their carried pipeline, and their
demonstrated productivity (won value per rep over the observable window). Distinguish dedicated
sellers from leadership or founders who are carrying pipeline opportunistically, because founder-
carried pipeline is not durable capacity and should be flagged as a structural risk rather than
counted as steady-state.

**Productivity per rep.** Won value and win count per active seller, and the implied annual run rate
per rep. This is the unit that all capacity math builds on. Where history is thin, mark the per-rep
productivity provisional and widen the estimate range.

**Quota coverage.** Total target divided by per-rep productive capacity gives the number of fully
ramped reps required. Compare to the actual ramped headcount to produce the capacity gap: how many
reps short or long the team is against the target. Account for ramp time, since a rep hired today
does not produce at full capacity for a quarter or two in an enterprise motion.

**Hiring runway.** Given the capacity gap and ramp time, when hiring must happen to have productive
capacity in place by the time the target requires it. This converts a static gap into a dated hiring
plan, which is the decision-useful output.

## Hamming framing

The current state, where the CEO and GTM lead carry essentially all worked pipeline, is the headline
capacity finding for Hamming. This is normal for the stage but is not durable capacity, and the model
should say so plainly: the team is founder-led on revenue, and scaling the number requires building
seller capacity that does not depend on the founders' time. Frame the quota-coverage gap as the case
for the first dedicated sales hires, with the dated runway.

## Output

Lead with the capacity verdict: can the current team hit the target, and if not, how many ramped reps
short. Then per-rep productivity, the quota-coverage gap, and the dated hiring runway. Tag
productivity Measured where history allows and provisional where thin, and flag founder-carried
pipeline as a structural risk every time.
