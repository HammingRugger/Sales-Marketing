---
name: source-attribution
description: >
  Tie lead sources, channels, and campaigns to won revenue, so spend and effort follow what actually
  converts rather than what produces deal count. Use whenever the user asks "which sources convert",
  "where does our best pipeline come from", "what's our best channel", "is outbound or inbound
  working better", or any question connecting origin to outcome. This skill is built ready but is
  gated hard by data-readiness, because source fields are frequently unpopulated, and a confident
  attribution built on blank data is worse than no answer. It inherits from cro-core. For creation
  volume regardless of source use pipeline-generation-coverage.
---

# Source and Channel Attribution

The CRO question here is simple and ruthless: which origins produce revenue, and which just produce
deals that die. A channel that generates a hundred deals and zero wins is a cost, not a source, and
this skill exists to find that out. But it only works if origin is captured, so the readiness gate
is not optional here, it is the first step.

## Readiness gate first

Run data-readiness-gate on hs_analytics_source, hs_analytics_latest_source, and referral_source
before computing anything. At last audit the original traffic source was collapsed to "Offline
Sources" on roughly 93% of deals, which is data-starved. If that condition holds, do not invent a
channel breakdown. State plainly that source is not yet captured, name the one behavior that fixes
it (setting source or referral_source at deal creation, or capturing UTM and offline source
consistently), and offer the one attribution proxy that is always available: creation-by-owner,
which at least shows whether pipeline originates from the team broadly or a few individuals.

## What it computes when source is ready

**Source-to-won conversion.** For each source, the count and value of deals created, the win rate,
and the won revenue. Rank sources by won revenue and by win rate, because the two rankings diverge
and the divergence is the insight: high-volume low-conversion sources versus low-volume
high-conversion ones.

**Cost-quality view.** Where source maps to a channel with known effort or spend, the won revenue
per unit of effort, so the team can shift toward what converts. If spend data is not in HubSpot,
report the conversion side and note that the cost side requires external data to complete.

**Referral and partner lift.** referral_source, when populated, often carries the highest-converting
origins for an enterprise motion. Surface partner and referral-sourced deals separately, since for
Hamming's depth-over-breadth motion these are usually the best pipeline.

## Output

If data-starved, a short honest statement of what is not yet measurable and the capture fix, plus
the owner-origin proxy. If ready, the source ranking by won revenue and by win rate, the divergence
read, and the recommendation of which origin to lean into. Tag everything Measured or Data-starved
with no middle ground, because half-populated source data is the most misleading kind.
