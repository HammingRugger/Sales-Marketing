---
name: forecast-accuracy-credibility
description: >
  Produce a defensible forecast range and score how much each owner's commit can be trusted given
  their track record of slips and category accuracy. Use whenever the user asks "what will we close",
  "what's the forecast", "can we trust the commit", "whose deals slip", or wants the call going into
  a board or revenue meeting. This is the discipline that separates a number from a guess: not just
  the expected value but the credibility of the people behind it. It inherits from cro-core and
  consults data-readiness-gate. For pipeline sufficiency use pipeline-generation-coverage; for the
  per-rep full read use rep-performance-scorecard.
---

# Forecast Accuracy and Credibility

A forecast is two things: a number, and the trustworthiness of the people who gave it. Most teams
report only the first. A CRO weights the second, because a committed deal from a rep who slips half
their commits is worth less than the same deal from a rep who calls it straight.

## The forecast range

Build three views and present a range, never a single point.
- **Probability-weighted:** sum of each open deal's amount times its stage probability. Fast, but
  trusts configured stage odds.
- **Conversion-weighted:** each open deal's amount times the empirical close rate for its stage from
  history. The gap between this and the probability-weighted number tells you whether the configured
  odds are realistic, which is itself a finding.
- **Category-weighted:** if forecast category and probability are populated (verify via
  data-readiness-gate, these are typically ready), weight by the rep's manual category. Compare to
  the two model views to see where rep optimism diverges from history.

Blend into a commit-to-stretch range and a risk-adjusted commit that removes at-risk and critical
deals identified by pipeline-inspection.

## Rep credibility scoring

This is the part that needs history and accrues over time. For each owner, track:
- **Slip rate:** how often their deals' close dates move later, and by how much. A rep whose deals
  push repeatedly is telling you their commits run early.
- **Category accuracy:** how often deals they marked commit or best-case actually closed in period.
- **Win-rate stability:** whether their close rate is consistent or volatile quarter to quarter.

Combine into a credibility weighting per rep, and apply it to discount or trust the portion of the
forecast each owner carries. Be explicit that in a freshly migrated portal this history is thin, so
the credibility model starts as a forward-accruing instrument: it gets sharper each quarter as slip
and category data accumulates. Until then, report it as provisional and lean on the model-based
views.

## Output

The forecast range (probability, conversion, category-weighted, blended, risk-adjusted), then the
per-owner credibility read with the slip and category-accuracy figures behind it, then a single
trusted commit that applies the credibility weighting. Tag the forecast math Measured, empirical
stage odds Measured with sample size, credibility provisional and Assessed until history is deep,
and gate any category-based view through data-readiness.
