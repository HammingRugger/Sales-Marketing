---
name: cro-board-narrative
description: >
  Assemble board-level and executive revenue communication from the agent's analysis: the concise,
  honest, decision-oriented narrative a CRO delivers to a board, CEO, or investors. Use whenever the
  user asks to "prep for the board", "write the revenue update", "summarize for the CEO", "build the
  QBR narrative", or wants the analysis turned into executive communication rather than an analyst
  report. This skill shapes delivery, not new analysis: it pulls from the other skills and renders
  the story leadership needs. It inherits voice and the evidence standard from cro-core.
---

# CRO Board Narrative

A board does not want a dashboard, it wants judgment: where revenue stands, what is working, what is
at risk, and what the CRO is doing about it. This skill turns the agent's analysis into that
narrative. It produces no new numbers; it selects, frames, and delivers the ones the other skills
already computed, at the altitude leadership operates at.

## The board narrative structure

Lead with the number and the call. The first lines state where revenue stands against target, the
forecast range with its confidence, and the one thing the CRO most wants the board to know. No
preamble.

Then four movements, each tight:
- **What is working.** The two or three genuine strengths, quantified, stated without hedging. A
  board needs to know what to keep funding.
- **What is at risk.** The honest risks: pipeline sufficiency, concentration, capacity, data gaps.
  Named plainly, because a board that senses hidden risk stops trusting the CRO. Each risk paired
  with its magnitude.
- **What we are doing about it.** The specific actions underway or proposed, each tied to the risk it
  addresses. This is what separates a CRO update from a status report.
- **What we need.** The asks: headcount, budget, board help, decisions. Concrete and defended.

## Honesty discipline for the boardroom

The board narrative is where the temptation to round up is strongest and most damaging. Carry the
Measured, Assessed, and Data-starved tags through as plain-language confidence: say what is known,
what is estimated, and what cannot yet be measured. A forecast given as a range with stated
confidence builds more trust than a single number delivered with false certainty. Where the data is
young or migrated, say so once, clearly, rather than letting the board over-read thin history. Never
present a starved-field proxy as a real metric to a board.

## Hamming framing

For Hamming's stage, the board's real questions are whether the revenue motion is founder-dependent,
whether pipeline generation can scale, and whether early deals are converting well enough to justify
investment in seller capacity. Anticipate these and answer them in the narrative before they are
asked.

## Output

A board-ready narrative, one page where possible, leading with the number and the call, then the four
movements, in clear executive prose with no analyst clutter. Offer it as a polished document or slide
outline when the user is presenting rather than reading. Keep every claim traceable back to a skill
that measured or assessed it.
