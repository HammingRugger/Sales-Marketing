---
name: cro-orchestrator
description: >
  The front door and router for the Hamming CRO agent. Use whenever the user wants a revenue
  evaluation but has not named a single specific skill, or says "run the CRO review", "evaluate the
  whole revenue picture", "do the quarterly revenue read", "how are we doing on revenue", "prep the
  full pipeline and forecast review", or hands over a broad revenue question. This skill reads the
  request, routes to the right specialist skills in the right order, and synthesizes their outputs
  into one coherent CRO read. For a single named analysis, call that specialist directly. It inherits
  methodology and the evidence standard from cro-core and always reads cro-core first.
---

# CRO Orchestrator

This skill is the conductor. It does not analyze; it routes and synthesizes. It reads what the user
is actually asking, selects the minimum set of specialist skills that answers it, runs them in
dependency order, and assembles one read rather than a pile of sections. The goal is that a broad
revenue question gets a CRO's answer, not fourteen disconnected reports.

## Read cro-core first

Always load cro-core before routing, so the Hamming context, the live-versus-latent data map, and the
evidence standard are in context. Then route.

## Routing logic

Match the request to the smallest sufficient set of skills.

- "How healthy is the pipeline / where are deals stalling" → pipeline-inspection.
- "Are we creating enough / forward coverage" → pipeline-generation-coverage.
- "What will we close / can we trust the forecast" → forecast-accuracy-credibility.
- "Is it getting better or worse / trend / cohort" → cohort-trend-analysis.
- "Which sources convert" → source-attribution.
- "Why are we losing / discount / deal quality" → win-loss-deal-quality.
- "Conversion economics / deal size / ACV" → velocity-conversion-economics.
- "Retention / churn / NRR / expansion" → retention-expansion-nrr.
- "Do we have enough reps / quota coverage" → capacity-quota-modeling.
- "How is each rep doing / break down by owner" → rep-performance-scorecard.
- "Prep for the board / revenue update" → cro-board-narrative, pulling from whatever it needs.

data-readiness-gate is not routed to directly; every skill consults it internally.

## The three standard runs

When the user wants a full evaluation rather than one answer, offer the right depth:

**Weekly pulse.** pipeline-inspection plus rep-performance-scorecard, focused on at-risk deals and
hygiene. Fast, operational, for the Monday review.

**Monthly deep evaluation.** pipeline-inspection, pipeline-generation-coverage,
forecast-accuracy-credibility, cohort-trend-analysis, velocity-conversion-economics, and
rep-performance-scorecard. The full operating read.

**Quarterly board read.** Everything in the monthly run plus capacity-quota-modeling,
retention-expansion-nrr, source-attribution and win-loss-deal-quality where data allows, all
assembled through cro-board-narrative.

Pick the run that matches the user's intent; default to asking which depth if it is ambiguous and the
request is broad.

## Synthesis discipline

The output is one read, not stapled sections. Open with the single CRO verdict: where revenue stands,
the forecast with confidence, and the one thing that most needs attention. Then let the causal thread
connect the skills: a generation shortfall, a thin-but-improving cohort, a founder-dependent capacity
picture, and a concentrated forecast are usually one story about the same business, and the synthesis
says so. Carry every confidence tag through. End with the ranked next moves, each defended in a
sentence, and the data-capture upgrades that would make the next read sharper.

## Output

One synthesized CRO read written to /mnt/user-data/outputs/, at the depth the run requires, with an
offer to render it as a board document, an interactive dashboard, or a workable spreadsheet depending
on whether the user will present it, monitor it, or act on it. Never fabricate to fill a gap; name the
gap and route around it.
