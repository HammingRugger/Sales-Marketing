---
name: pipeline-generation-coverage
description: >
  Measure whether enough new pipeline is being created, fast enough, to hit future quarters, not just
  the current one. Use whenever the user asks "are we creating enough pipeline", "what's our pipeline
  generation rate", "do we have enough coverage for next quarter", "is new business keeping up", or
  any forward-looking sufficiency question. This is the single question a CRO asks first, because by
  the time the current pipeline is unhealthy it is already too late to fix this quarter. It inherits
  from cro-core and consults data-readiness-gate. For present-state health use pipeline-inspection;
  for direction over time use cohort-trend-analysis.
---

# Pipeline Generation and Coverage

Pipeline inspection tells you about the deals you have. This skill tells you whether you will have
enough deals next quarter, which is the more important and more neglected question. Coverage measured
against the current period is a lagging comfort; coverage measured forward against future targets is
where a CRO actually lives.

## What it computes

**Net-new pipeline creation rate.** Count and value of deals created per week and per month over the
trailing window, excluding any bulk-migration cohort identified per cro-core. The trend is the
point: is creation accelerating, flat, or decaying. A flat or decaying creation rate is an early
warning that no amount of working the current pipeline can offset.

**Forward coverage.** Project the open qualified pipeline that will be available to close in each
of the next one to two quarters, given the account's cycle length, against the target for those
quarters. This is different from current-period coverage because it asks whether today's pipeline
plus expected creation will mature in time. Report the coverage gap per future quarter as a dollar
figure, not just a ratio.

**Creation-to-target math.** Given the historical win rate and average deal size, how many net-new
qualified deals must be created per week to sustain the forward target. Compare to the actual
creation rate to produce a simple sufficiency verdict: generating enough, or short by N deals per
week. This is the most decision-useful single number this skill produces.

**Source of creation.** Where new pipeline is coming from, gated through data-readiness. If source
capture is starved, say so and fall back to creation-by-owner, which is always available, to show
whether net-new is coming from the team broadly or from one or two people.

## Hamming framing

For an enterprise infrastructure motion with long cycles, forward coverage matters more than for a
fast transactional motion, because a generation shortfall today does not show up in revenue for two
or three quarters and cannot be corrected late. Weight the forward view accordingly and push the
creation-rate trend to the front of the read.

## Output

Lead with the sufficiency verdict: are we creating enough net-new qualified pipeline per week to hit
the forward target, and if not, the size of the weekly shortfall. Then the creation-rate trend, the
forward coverage gap per quarter, and where creation is concentrated. Tag creation counts Measured,
forward projections Assessed with the cycle and win-rate assumptions named, and any source claim
gated through data-readiness.
