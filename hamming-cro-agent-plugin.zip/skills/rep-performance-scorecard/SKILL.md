---
name: rep-performance-scorecard
description: >
  Produce a per-seller scorecard across the dimensions a CRO uses in a one-on-one: pipeline carried,
  win rate, average deal size, activity and tracking discipline, slip and credibility, and overdue
  exposure. Use whenever the user asks "how is each rep doing", "break it down by owner", "who's
  performing", "compare my reps", or wants the individual read behind the aggregate. This is the skill
  that turns pipeline data into coaching and accountability. It inherits from cro-core and draws
  credibility inputs from forecast-accuracy-credibility. For team-level capacity use
  capacity-quota-modeling.
---

# Rep Performance Scorecard

The aggregate hides the individuals. This skill resolves owner IDs to people and builds the per-rep
read a CRO actually uses to run a one-on-one: not just who is winning, but who tracks their deals,
who slips their commits, and whose pipeline is real versus stored. It is the accountability layer.

## What it computes per rep

**Volume and value.** Open deals carried and their value, split by stage, so a rep's pipeline shape
is visible, not just its size. A rep with all early-stage pipeline is in a different position than one
with a loaded late stage.

**Outcomes.** Win count, loss count, win rate, and won value over the observable window, computed on
the post-migration cohort so the numbers reflect real selling. Average and median deal size per rep,
since a high-volume small-deal seller and a low-volume large-deal seller need different coaching.

**Discipline.** Activity-tracking rate (share of the rep's deals with logged contact) and recency.
This is a fairness check as much as a performance one: a rep whose deals show no activity may be
under-tracking rather than under-working, and the scorecard should distinguish the two by looking at
whether tracked deals progress.

**Credibility.** Slip rate and forecast-category accuracy from forecast-accuracy-credibility, marked
provisional where history is thin. This is the input to how much of the rep's commit to trust.

**Exposure.** The rep's overdue and at-risk deals by value, so the one-on-one starts with the deals
that need rescue.

## Fairness and framing discipline

Resolve owner IDs to names before reporting, and state each person's role, because a founder or GTM
lead carrying pipeline is not comparable to a dedicated rep and should not be ranked against one as
if they were. Distinguish under-tracking from under-performing explicitly. The goal is an honest read
that supports coaching, not a leaderboard that punishes the person with the messier territory.

## Output

One scorecard block per active seller, leading with their headline (carrying X, winning at Y, tracking
at Z), then the volume, outcomes, discipline, credibility, and exposure rows, ending with the one
coaching focus the data most supports for that person. Offer the comparison as a spreadsheet when the
user wants to sort and filter. Tag outcomes Measured on the real cohort, credibility provisional where
thin, and always name role alongside name.
